from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.callbacks import TensorBoard
from keras_tqdm import TQDMCallback
import pickle
import time

pickle_in = open("x.pickle","rb") #Objective 4.e Import processed image files
X = pickle.load(pickle_in)

pickle_in = open("y.pickle","rb") #Objective 4.e Import corresponding one-hot encoded labels
Y = pickle.load(pickle_in)

X = X/255.0

print("Name:")
NAME =str(input())

model = Sequential()

model.add(Conv2D(64, (5, 5), input_shape=X.shape[1:], padding = "SAME")) #Objective 3.a
model.add(Activation('relu')) #Objective 3.c
model.add(Conv2D(64, (5, 5), input_shape=X.shape[1:], padding = "SAME")) #Objective 3.b
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(128, (3, 3), input_shape=X.shape[1:], padding = "SAME"))
model.add(Activation('relu'))
model.add(Conv2D(128, (3, 3), input_shape=X.shape[1:], padding = "SAME"))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Dropout(0.2))

model.add(Flatten()) #Objective 3.d
model.add(Dense(128)) #Dense layers are equivalent to Fully connected layers
model.add(Activation('relu'))

model.add(Dense(52,activation = 'softmax')) #Objective 3.e

tensorboard = TensorBoard(log_dir="logs/{}".format(NAME)) #Using tensorboard to monitor training process

model.compile(loss='categorical_crossentropy',
              optimizer='adam',
              metrics=['accuracy'],
              )

model.fit(X, Y,
          batch_size=64,
          epochs= 11,
          validation_split=0.3,
          verbose = 0,
          callbacks=[tensorboard,TQDMCallback()])

model.save('Models/{}.model'.format(NAME))
