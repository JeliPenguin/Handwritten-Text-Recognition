import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import random
import pickle
import sys
sys.path.append('../')
from Picture_Preprocess.Image_preprocess_class import Image_Preprocess

#DATADIR = "C:/Users/Jeffrey/Desktop/Dataset/Alphabet/Processed/"
DATADIR = "C:/Users/Jeffrey/Desktop/Dataset/Alphabet/Test Sets/Test_Set_For_Smaller_Set"
training_data = []
IMG_SIZE = 28 #Requires set dimensions for all images
              #Training data are all 28 * 28 pixels
CATEGORIES = ["A","A1","B","B1","C","C1","D","D1","E","E1","F","F1","G","G1",
              "H","H1","I","I1","J","J1","K","K1","L","L1","M","M1","N","N1",
              "O","O1","P","P1","Q","Q1","R","R1","S","S1","T","T1",
              "U","U1","V","V1","W","W1","X","X1","Y","Y1","Z","Z1"] #Labels for classes Each containing around 9000 images
category_length = len(CATEGORIES)
img_pps = Image_Preprocess()
files = []
files = [f for f in sorted(os.listdir(DATADIR))]

def create_training_data():
    counter = 0
    for category in CATEGORIES:
        path = os.path.join(DATADIR,files[counter]) #path to Handwritten alphabet images
        class_label = CATEGORIES.index(category) #Objective 4.c
        image_count = 0
        for img in os.listdir(path):
            try:
                #Objective 4.b
                img_pps.img = cv2.imread(path + '/'+img,cv2.IMREAD_GRAYSCALE)
                image_array = np.asarray(img_pps.img)
                mean = np.mean(image_array)
                if mean < 100: #Do Thresholding when it's black background
                    ret,thresh = cv2.threshold(img_pps.img,125,255,cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
                    img_pps.img = thresh
                img_pps.image_array = img_pps.img.tolist()
                final = img_pps.image_resize(img_pps.crop_whole_image(img_pps.image_array),28)
                training_data.append([final,class_label])
                image_count += 1
            except Exception as e:
                print("Error")
        if len(category) < 2:
            category_name = category+ " "
            file_name = files[counter]+ " "
        else:
            category_name = category
            file_name = files[counter]
        print(category_name, "completed","|    Path: ",file_name,"|    Class Label: ",str(class_label),"|    Number of Images: ",str(image_count))
        counter += 1
        

def to_one_hot(labels,length):
    dim = length
    results = np.zeros((len(labels),dim))
    for i, label in enumerate(labels):
        results[i,label] = 1
    return results

create_training_data()
random.shuffle(training_data) #Randomizing training data

x = [] #Features
y = [] #Labels

for features, label in training_data:
    x.append(features)
    y.append(label)

x = np.array(x).reshape(-1,IMG_SIZE,IMG_SIZE, 1) #Creating tensor of shape (IMG_SIZE,IMG_SIZE) grayscale
y = to_one_hot(y,category_length) #Objective 4.c, Turning Labels into one hot array
pickle_out = open("x.pickle","wb") #Objective 4.d
pickle.dump(x,pickle_out)
pickle_out.close()

pickle_out = open("y.pickle","wb") #Objective 4.d
pickle.dump(y,pickle_out)
pickle_out.close()

wait = input()
